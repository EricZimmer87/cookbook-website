package com.cookbookwebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookbookwebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
